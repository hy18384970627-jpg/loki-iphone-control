HID implementation (`hid_bridge.cpp`, `hid_bridge.h`, `tick_context.h`) adapted from
https://github.com/xiaozhuai/iscrcpy commit d75aeab56a4a07f981880ea7a6d9d69875bc5eeb.
Original MIT copyright and license are preserved in LICENSE.iscrcpy.
The custom BLE control service and protocol are local Loki adaptations.
No Wi-Fi configuration or credentials are required by this firmware.
