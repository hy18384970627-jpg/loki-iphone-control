#pragma once
#include <cstdint>
namespace config {
inline constexpr char kHidManufacturerName[] = "Loki (iscrcpy HID base)";
inline constexpr uint16_t kHidVendorId = 0x303A;
inline constexpr uint16_t kHidProductId = 0x1001;
}
