#pragma once
#include <cstddef>
#include <cstdint>
#include <cstring>

// Fixed 16-byte packets fit the default ATT payload. No network credentials.
namespace loki {
constexpr char kService[] = "7a3d0001-7d16-4d90-a302-10c97ab12c10";
constexpr char kCommand[] = "7a3d0002-7d16-4d90-a302-10c97ab12c10";
constexpr char kReply[] = "7a3d0003-7d16-4d90-a302-10c97ab12c10";
constexpr uint32_t kLeaseMs = 1500;
enum class Op : uint8_t { ping=1, move=2, button=3, key=4, release=5, arm=6 };
enum class Status : uint8_t { ok=0, invalid=1, disarmed=2, stale=3, rejected=4, busy=5 };
struct Command { Op op{}; uint32_t seq{}; int16_t a{},b{},c{},d{}; };
inline uint32_t u32(const uint8_t *p) {
    return uint32_t(p[0]) | uint32_t(p[1])<<8 | uint32_t(p[2])<<16 | uint32_t(p[3])<<24;
}
inline int16_t i16(const uint8_t *p) { return int16_t(uint16_t(p[0]) | uint16_t(p[1])<<8); }
inline void put32(uint8_t *p, uint32_t n) { for (int i=0;i<4;++i) p[i]=uint8_t(n>>(8*i)); }
inline uint32_t crc32(const uint8_t *p, size_t n) {
    uint32_t value=0xffffffff;
    for (size_t i=0;i<n;++i) {
        value^=p[i];
        for (int bit=0;bit<8;++bit) value=(value>>1)^(0xedb88320u & (0u-(value&1u)));
    }
    return ~value;
}
inline bool decode(const uint8_t *p, size_t n, Command &out) {
    if (n!=16 || p[0]!='L' || p[1]!='K' || p[2]!=1 || p[3]<1 || p[3]>6) return false;
    out={Op(p[3]),u32(p+4),i16(p+8),i16(p+10),i16(p+12),i16(p+14)};
    if (!out.seq) return false;
    switch (out.op) {
        case Op::move: return out.a>=-127 && out.a<=127 && out.b>=-127 && out.b<=127 &&
                             out.c>=-127 && out.c<=127 && out.d>=-127 && out.d<=127;
        case Op::button: return (out.a==1 || out.a==2 || out.a==4 || out.a==8 || out.a==16) &&
                              (out.b==0 || out.b==1) && out.c==0 && out.d==0;
        case Op::key: return ((out.a>=4 && out.a<=0x65) || (out.a>=0xe0 && out.a<=0xe7)) &&
                            (out.b==0 || out.b==1) && out.c==0 && out.d==0;
        case Op::arm: return (out.a==0 || out.a==1) && out.b==0 && out.c==0 && out.d==0;
        default: return out.a==0 && out.b==0 && out.c==0 && out.d==0;
    }
}
// A session must explicitly arm after reconnect/timeout. Sequence numbers never wrap.
struct Lease {
    uint32_t sequence=0, last_ms=0;
    bool armed=false;
    bool expire(uint32_t now) {
        if (armed && uint32_t(now-last_ms)>kLeaseMs) { armed=false; return true; }
        return false;
    }
    Status accept(const Command &cmd, uint32_t now) {
        if (cmd.seq<=sequence) return Status::stale;
        sequence=cmd.seq;
        if (cmd.op==Op::arm) { armed=cmd.a==1; last_ms=now; return Status::ok; }
        if (cmd.op==Op::release) { armed=false; return Status::ok; }
        if (cmd.op==Op::ping) { if (armed) last_ms=now; return Status::ok; }
        return armed ? Status::ok : Status::disarmed;
    }
};
}
