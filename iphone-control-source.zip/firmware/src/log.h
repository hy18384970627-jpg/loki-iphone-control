#pragma once
#include <Arduino.h>
#define LOGI(...) do { Serial.printf(__VA_ARGS__); Serial.println(); } while (0)
#define LOGW(...) LOGI(__VA_ARGS__)
#define LOGE(...) LOGI(__VA_ARGS__)
