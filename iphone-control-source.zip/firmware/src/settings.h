#pragma once
#include <string>
namespace settings {
inline std::string get_device_name() { return "Loki S3 Control"; }
}
