import Foundation
import Combine
@preconcurrency import CoreBluetooth

// One in-flight command. Completion requires the board's matching sequence reply,
// not just CoreBluetooth didWriteValue. No automatic replay on an uncertain write.
@MainActor final class PhoneControlBLE: NSObject, ObservableObject, CBCentralManagerDelegate, CBPeripheralDelegate {
    @Published private(set) var state="尚未连接配件"
    @Published private(set) var ready=false
    @Published private(set) var roundTripMS: Double?
    @Published private(set) var armed=false
    private var central: CBCentralManager!
    private var peer: CBPeripheral?
    private var command: CBCharacteristic?
    private var reply: CBCharacteristic?
    private var sequence: UInt32=0
    private var pending: (UInt32,ContinuousClock.Instant,CheckedContinuation<PhoneControlWire.Reply,Error>)?
    private var deadline: Task<Void,Never>?
    private(set) var generation=UUID()
    var onDisconnect: (() -> Void)?
    override init() { super.init(); central=CBCentralManager(delegate:self,queue:.main) }
    func connect() {
        guard central.state == .poweredOn else { state="请开启并允许 Loki 使用蓝牙"; return }
        guard peer==nil else { return }
        state="查找 Loki S3 Control…"
        let services=[CBUUID(string:PhoneControlWire.service), CBUUID(string:"1812")]
        if let active=central.retrieveConnectedPeripherals(withServices:services)
            .first(where: { $0.name == "Loki S3 Control" }) { attach(active); return }
        central.scanForPeripherals(withServices:nil,options:[CBCentralManagerScanOptionAllowDuplicatesKey:false])
        deadline?.cancel()
        deadline=Task { [weak self] in
            try? await Task.sleep(for:.seconds(15))
            guard !Task.isCancelled, let self, self.peer==nil else { return }
            self.central.stopScan(); self.state="未找到配件，请先在辅助触控中配对 Loki S3 Control"
        }
    }
    private func attach(_ p:CBPeripheral) {
        deadline?.cancel(); central.stopScan(); peer=p; p.delegate=self
        generation=UUID(); state="连接配件…"; central.connect(p)
        deadline=Task { [weak self] in
            try? await Task.sleep(for:.seconds(20))
            guard !Task.isCancelled, let self, !self.ready else { return }
            self.disconnect("连接超时，请检查辅助触控配对")
        }
    }
    func disconnect(_ reason:String="已断开配件") {
        deadline?.cancel()
        if let pending { self.pending=nil; pending.2.resume(throwing:PhoneControlFailure.message(reason)) }
        ready=false; armed=false; command=nil; reply=nil; generation=UUID(); sequence=0
        let previous=peer; peer=nil
        if let previous { central.cancelPeripheralConnection(previous) }
        state=reason; onDisconnect?()
    }
    func send(_ op:PhoneControlWire.Op,a:Int16=0,b:Int16=0,c:Int16=0,d:Int16=0) async throws -> PhoneControlWire.Reply {
        try Task.checkCancellation()
        guard ready, let peer, let command, pending==nil else { throw PhoneControlFailure.message("配件未就绪或仍在处理上一指令") }
        guard sequence < UInt32.max else { disconnect(); throw PhoneControlFailure.message("请重新连接配件") }
        sequence+=1; let current=sequence; let session=generation
        let bytes=PhoneControlWire.packet(op,sequence:current,a:a,b:b,c:c,d:d)
        return try await withTaskCancellationHandler(operation: {
            try await withCheckedThrowingContinuation { continuation in
                pending=(current,ContinuousClock.now,continuation)
                peer.writeValue(bytes,for:command,type:.withResponse)
                deadline?.cancel()
                deadline=Task { [weak self] in
                    try? await Task.sleep(for:.seconds(2))
                    guard !Task.isCancelled, let self, self.generation==session,
                          self.pending?.0==current else { return }
                    self.disconnect("指令超时，已停止；不会重复发送")
                }
            }
        }, onCancel: { Task { @MainActor [weak self] in
            guard let self, self.generation==session, self.pending?.0==current else { return }
            self.disconnect("操作已取消")
        } })
    }
    func centralManagerDidUpdateState(_ central:CBCentralManager) {
        if central.state != .poweredOn { central.stopScan(); disconnect("蓝牙不可用") }
    }
    func centralManager(_ central:CBCentralManager,didDiscover peripheral:CBPeripheral,
                        advertisementData:[String:Any],rssi RSSI:NSNumber) {
        let name=(advertisementData[CBAdvertisementDataLocalNameKey] as? String) ?? peripheral.name
        guard peer==nil, name=="Loki S3 Control" else { return }; attach(peripheral)
    }
    func centralManager(_ central:CBCentralManager,didConnect peripheral:CBPeripheral) {
        guard peripheral===peer else { return }
        peripheral.discoverServices([CBUUID(string:PhoneControlWire.service)])
    }
    func centralManager(_ central:CBCentralManager,didFailToConnect peripheral:CBPeripheral,error:Error?) {
        guard peripheral===peer else { return }; disconnect("连接失败，请重新选择配件")
    }
    func centralManager(_ central:CBCentralManager,didDisconnectPeripheral peripheral:CBPeripheral,error:Error?) {
        guard peripheral===peer else { return }; disconnect("配件已断开")
    }
    func peripheral(_ peripheral:CBPeripheral,didDiscoverServices error:Error?) {
        guard peripheral===peer else { return }
        guard error==nil,let service=peripheral.services?.first(where:{$0.uuid==CBUUID(string:PhoneControlWire.service)})
        else { disconnect("配件服务不可用"); return }
        peripheral.discoverCharacteristics([CBUUID(string:PhoneControlWire.command),CBUUID(string:PhoneControlWire.reply)],for:service)
    }
    func peripheral(_ peripheral:CBPeripheral,didDiscoverCharacteristicsFor service:CBService,error:Error?) {
        guard peripheral===peer else { return }
        guard error==nil else { disconnect("读取配件失败"); return }
        command=service.characteristics?.first(where:{$0.uuid==CBUUID(string:PhoneControlWire.command)})
        reply=service.characteristics?.first(where:{$0.uuid==CBUUID(string:PhoneControlWire.reply)})
        guard command?.properties.contains(.write)==true,let reply,
              reply.properties.contains(.notify) else { disconnect("固件协议不匹配"); return }
        peripheral.setNotifyValue(true,for:reply)
    }
    func peripheral(_ peripheral:CBPeripheral,didUpdateNotificationStateFor characteristic:CBCharacteristic,error:Error?) {
        guard peripheral===peer,characteristic===reply else { return }
        guard error==nil,characteristic.isNotifying else { disconnect("配件通知未就绪"); return }
        deadline?.cancel(); ready=true; state="已连接；尚未允许操作"
    }
    func peripheral(_ peripheral:CBPeripheral,didWriteValueFor characteristic:CBCharacteristic,error:Error?) {
        guard peripheral===peer,characteristic===command else { return }
        if error != nil { disconnect("配件拒绝指令，请检查系统配对") }
    }
    func peripheral(_ peripheral:CBPeripheral,didUpdateValueFor characteristic:CBCharacteristic,error:Error?) {
        guard peripheral===peer,characteristic===reply, error==nil,
              let bytes=characteristic.value,let result=PhoneControlWire.decode(bytes),
              let pending,pending.0==result.sequence else { return }
        self.pending=nil; deadline?.cancel(); armed=result.armed
        let elapsed=pending.1.duration(to:.now).components
        roundTripMS=Double(elapsed.seconds)*1000+Double(elapsed.attoseconds)/1e15
        if result.status != 0 { pending.2.resume(throwing:PhoneControlFailure.message("配件停止执行（状态 \(result.status)）")) }
        else { pending.2.resume(returning:result) }
    }
    func peripheral(_ peripheral:CBPeripheral,didModifyServices invalidatedServices:[CBService]) {
        guard peripheral===peer else { return }; disconnect("配件服务已改变，请重新连接")
    }
}
