import Foundation

enum PhoneControlWire {
    static let service = "7a3d0001-7d16-4d90-a302-10c97ab12c10"
    static let command = "7a3d0002-7d16-4d90-a302-10c97ab12c10"
    static let reply = "7a3d0003-7d16-4d90-a302-10c97ab12c10"
    enum Op: UInt8 { case ping=1, move=2, button=3, key=4, release=5, arm=6 }
    struct Reply {
        let sequence: UInt32
        let status: UInt8
        let boardMicroseconds: UInt32
        let connected: Bool
        let armed: Bool
    }
    static func packet(_ op: Op, sequence: UInt32, a: Int16=0, b: Int16=0,
                       c: Int16=0, d: Int16=0) -> Data {
        var bytes: [UInt8] = [76,75,1,op.rawValue]
        bytes += (0..<4).map { UInt8(truncatingIfNeeded: sequence >> ($0*8)) }
        for value in [a,b,c,d] {
            let bits=UInt16(bitPattern:value)
            bytes += [UInt8(truncatingIfNeeded:bits),UInt8(truncatingIfNeeded:bits>>8)]
        }
        return Data(bytes)
    }
    static func decode(_ data: Data) -> Reply? {
        let p=Array(data)
        guard p.count==16, p[0]==76, p[1]==75, p[2]==1, p[3]<=5,
              p[12]<=1, p[13]<=1, p[14]==0, p[15]==0 else { return nil }
        func u32(_ i:Int)->UInt32 { (0..<4).reduce(UInt32(0)) { $0 | UInt32(p[i+$1]) << ($1*8) } }
        return Reply(sequence:u32(4),status:p[3],boardMicroseconds:u32(8),connected:p[12]==1,armed:p[13]==1)
    }
}

enum PhoneControlFailure: LocalizedError {
    case message(String)
    var errorDescription: String? { if case .message(let text)=self { return text }; return nil }
}
