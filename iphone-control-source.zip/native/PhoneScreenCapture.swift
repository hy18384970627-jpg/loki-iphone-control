import Foundation
import Combine
import UIKit
import CoreImage
import CoreMedia
import CoreVideo
import CryptoKit
#if canImport(ScreenCaptureKit) && LOKI_IOS27_CAPTURE
@preconcurrency import ScreenCaptureKit
#endif

struct PhoneScreenFrame {
    let image: UIImage
    let jpeg: Data
    let fingerprint: String
    let capturedAt: Date
    let confirmedAt: Date
    let session: UUID
    let fullDisplay: Bool
}

@available(iOS 27.0,*)
@MainActor final class PhoneScreenCapture: ObservableObject {
    @Published private(set) var frame:PhoneScreenFrame?
    @Published private(set) var state="尚未共享屏幕"
    @Published private(set) var active=false
    var onUnavailable:(()->Void)?
    private var generation=UUID()
    #if canImport(ScreenCaptureKit) && LOKI_IOS27_CAPTURE
    private var engine:PhoneScreenEngine?
    #endif
    func start() {
        stop()
        #if canImport(ScreenCaptureKit) && LOKI_IOS27_CAPTURE
        if #available(iOS 27.0,*) {
            let id=UUID(); generation=id; state="请在系统选择器中共享整个屏幕"
            let next=PhoneScreenEngine { [weak self] value,status in
                Task { @MainActor in
                    guard let self,self.generation==id else { return }
                    self.frame=value; self.state=status; self.active=value?.fullDisplay==true
                    if value==nil { self.onUnavailable?() }
                }
            }
            engine=next; next.present()
        } else { state="整屏共享需要 iOS 27" }
        #else
        state="此构建未包含 iOS 27 屏幕共享模块"
        #endif
    }
    func stop() {
        generation=UUID()
        #if canImport(ScreenCaptureKit) && LOKI_IOS27_CAPTURE
        if #available(iOS 27.0,*) { engine?.stop(); engine=nil }
        #endif
        frame=nil; active=false; state="共享已停止"; onUnavailable?()
    }
    func current() throws -> PhoneScreenFrame {
        guard let frame,frame.fullDisplay,Date().timeIntervalSince(frame.confirmedAt)<1.2 else {
            throw PhoneControlFailure.message("等待新鲜的整屏画面")
        }
        return frame
    }
}

#if canImport(ScreenCaptureKit) && LOKI_IOS27_CAPTURE
@available(iOS 27.0,*)
private final class PhoneScreenEngine:NSObject,SCContentSharingPickerObserver,SCStreamDelegate,SCStreamOutput {
    private let report:(PhoneScreenFrame?,String)->Void
    private let queue=DispatchQueue(label:"loki.phone.capture")
    private let context=CIContext(options:[.cacheIntermediates:false])
    private let lock=NSLock()
    private var stream:SCStream?
    private var session=UUID()
    private var stopped=false
    // These are used only on the serial sample queue.
    private var cached:PhoneScreenFrame?
    private var renderedSession:UUID?
    private var lastEmission=Date.distantPast
    private var pending:(CVPixelBuffer,Date)?
    init(report:@escaping(PhoneScreenFrame?,String)->Void) { self.report=report; super.init() }
    func present() {
        let picker=SCContentSharingPicker.shared
        guard picker.isAvailable else { report(nil,"系统暂不允许共享屏幕"); return }
        picker.add(self); picker.isActive=true; picker.present()
    }
    func stop() {
        lock.lock(); stopped=true; session=UUID(); let previous=stream; stream=nil; lock.unlock()
        let picker=SCContentSharingPicker.shared; picker.remove(self); picker.isActive=false
        previous?.stopCapture { _ in }
    }
    private func valid(_ candidate:SCStream)->(UUID,Bool)? {
        lock.lock(); defer {lock.unlock()}
        guard !stopped,stream===candidate else {return nil}; return(session,true)
    }
    func contentSharingPicker(_ picker:SCContentSharingPicker,didUpdateWith filter:SCContentFilter,for stream:SCStream?) {
        guard filter.style == .display else { report(nil,"请选择整个屏幕以操作其他 App"); stop(); return }
        let options=SCStreamConfiguration(); options.capturesAudio=false
        let size=filter.contentRect.size; let scale=CGFloat(filter.pointPixelScale)
        options.width=max(1,Int(size.width*scale)); options.height=max(1,Int(size.height*scale))
        let next=SCStream(filter:filter,configuration:options,delegate:self)
        lock.lock()
        guard !stopped else {lock.unlock();return}
        let previous=self.stream; self.stream=next; session=UUID(); lock.unlock()
        previous?.stopCapture { _ in }; report(nil,"等待共享画面…")
        do {
            try next.addStreamOutput(self,type:.screen,sampleHandlerQueue:queue)
            next.startCapture { [weak self] error in
                if error != nil,self?.valid(next) != nil {self?.report(nil,"启动共享失败，请重试")}
            }
        } catch {report(nil,"无法启动共享，请重试")}
    }
    func contentSharingPicker(_ picker:SCContentSharingPicker,didCancelFor stream:SCStream?) {
        report(nil,"已取消共享");stop()
    }
    func contentSharingPickerStartDidFailWithError(_ error:Error) {report(nil,"打开共享选择器失败");stop()}
    func stream(_ stream:SCStream,didStopWithError error:Error) {
        guard valid(stream) != nil else {return};report(nil,"系统已停止共享");stop()
    }
    func stream(_ stream:SCStream,didOutputSampleBuffer sample:CMSampleBuffer,of type:SCStreamOutputType) {
        guard type == .screen, let (id,_)=valid(stream) else {return}
        if renderedSession != id {cached=nil;pending=nil;renderedSession=id;lastEmission = .distantPast}
        guard CMSampleBufferIsValid(sample),
              let attachments=CMSampleBufferGetSampleAttachmentsArray(sample,createIfNecessary:false) as? [[SCStreamFrameInfo:Any]],
              let raw=attachments.first?[.status] as? Int,let status=SCFrameStatus(rawValue:raw) else {
            cached=nil;pending=nil;report(nil,"等待完整画面");return
        }
        let now=Date()
        if status == .idle {
            if let final=pending {
                pending=nil;render(final.0,capturedAt:final.1,confirmedAt:now,id:id,stream:stream);return
            }
            // Only a system idle callback confirms an unchanged frame is still current.
            guard let old=cached,now.timeIntervalSince(lastEmission)>=0.2 else{return}
            lastEmission=now
            report(PhoneScreenFrame(image:old.image,jpeg:old.jpeg,fingerprint:old.fingerprint,
                 capturedAt:old.capturedAt,confirmedAt:now,session:id,fullDisplay:true),"正在共享屏幕")
            return
        }
        guard status == .complete,let pixel=CMSampleBufferGetImageBuffer(sample) else {
            cached=nil;pending=nil;report(nil,"画面暂不可用，已暂停操作");return
        }
        // Coalesce to five JPEGs per second, retaining the final changed pixels.
        cached=nil;pending=(pixel,now)
        guard now.timeIntervalSince(lastEmission)>=0.2 else{return}
        pending=nil;render(pixel,capturedAt:now,confirmedAt:now,id:id,stream:stream)
    }
    private func render(_ pixel:CVPixelBuffer,capturedAt:Date,confirmedAt:Date,id:UUID,stream:SCStream) {
        autoreleasepool {
            let source=CIImage(cvPixelBuffer:pixel)
            let ratio=min(1,1024/max(source.extent.width,source.extent.height))
            let image=source.transformed(by:CGAffineTransform(scaleX:ratio,y:ratio))
            guard let cg=context.createCGImage(image,from:image.extent) else {cached=nil;return}
            let ui=UIImage(cgImage:cg)
            guard let jpeg=ui.jpegData(compressionQuality:0.65) else {cached=nil;return}
            let fingerprint=SHA256.hash(data:jpeg).map {String(format:"%02x",$0)}.joined()
            let frame=PhoneScreenFrame(image:ui,jpeg:jpeg,fingerprint:fingerprint,capturedAt:capturedAt,
                                      confirmedAt:confirmedAt,session:id,fullDisplay:true)
            cached=frame;lastEmission=confirmedAt
            guard valid(stream)?.0==id else{return};report(frame,"正在共享屏幕")
        }
    }
}
#endif
