"""Measure USB serial round trips; sends PING only, never arms or clicks a phone."""
import argparse
import json
import secrets
import statistics
import struct
import time
import zlib

import serial


def packet(sequence):
    body=struct.pack('<2sBBIhhhh',b'LK',1,1,sequence,0,0,0,0)
    return body+struct.pack('<I',zlib.crc32(body))


def receive(port,sequence,deadline):
    pending=bytearray()
    while time.monotonic()<deadline:
        pending.extend(port.read(256))
        while len(pending)>=20:
            index=pending.find(b'LK')
            if index<0:
                pending=pending[-1:];break
            if index:del pending[:index]
            if len(pending)<20:break
            body=bytes(pending[:16])
            crc=struct.unpack('<I',pending[16:20])[0]
            if body[2]!=1 or zlib.crc32(body)!=crc:
                del pending[0];continue
            del pending[:20]
            _,version,status,seq,micros,connected,armed,_,_=struct.unpack('<2sBBIIBBBB',body)
            if seq!=sequence:continue
            if status or armed:raise RuntimeError('Unexpected status or armed state during PING-only probe')
            return {'board_us':micros,'phone_usb_connected':bool(connected),'armed':bool(armed)}
    raise TimeoutError('No matching CRC-verified reply. This probe requires the wired candidate firmware.')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port',required=True)
    parser.add_argument('--count',type=int,default=20)
    args=parser.parse_args()
    if not 1<=args.count<=100:parser.error('count must be 1..100')
    link=serial.Serial(port=None,baudrate=115200,timeout=0.02,write_timeout=0.5)
    link.dtr=False;link.rts=False;link.port=args.port
    values=[];sequence=secrets.randbelow(1_000_000)+1
    with link:
        for index in range(args.count):
            seq=sequence+index;start=time.perf_counter()
            link.write(packet(seq));reply=receive(link,seq,time.monotonic()+2)
            values.append((time.perf_counter()-start)*1000)
    print(json.dumps({'samples':len(values),'median_usb_roundtrip_ms':round(statistics.median(values),2),
                      'max_usb_roundtrip_ms':round(max(values),2),'last_reply':reply,
                      'phone_input_sent':False,'measured_model_latency':False,
                      'measured_visible_click_latency':False}))


if __name__=='__main__':main()
