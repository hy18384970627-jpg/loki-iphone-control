#include <cassert>
#include <cstdio>
#include <limits>
#include "../firmware/src/control_protocol.h"

int main() {
    using namespace loki;
    assert(crc32(reinterpret_cast<const uint8_t *>("123456789"),9)==0xcbf43926);
    uint8_t bytes[16]={'L','K',1,uint8_t(Op::move)};
    put32(bytes+4,0x01020304); bytes[8]=0x81;bytes[9]=0xff;bytes[10]=127;
    Command command;
    assert(decode(bytes,16,command));
    assert(command.seq==0x01020304 && command.a==-127 && command.b==127);
    assert(!decode(bytes,15,command));
    bytes[8]=0x80;assert(!decode(bytes,16,command)); // -128 outside HID's declared range.
    bytes[8]=0;bytes[9]=0;bytes[2]=2;assert(!decode(bytes,16,command));bytes[2]=1;
    bytes[3]=uint8_t(Op::key);bytes[8]=3;bytes[10]=1;assert(!decode(bytes,16,command));
    bytes[8]=0xe0;assert(decode(bytes,16,command));
    bytes[12]=1;assert(!decode(bytes,16,command));bytes[12]=0;
    put32(bytes+4,0);assert(!decode(bytes,16,command));
    Lease lease;
    assert(lease.accept({Op::move,1,1},0)==Status::disarmed);
    assert(lease.accept({Op::arm,2,1},1)==Status::ok && lease.armed);
    assert(lease.accept({Op::button,3,1,1},2)==Status::ok);
    assert(lease.accept({Op::button,3,1,1},3)==Status::stale); // Never replay a click.
    assert(lease.accept({Op::arm,2,1},3)==Status::stale);
    assert(!lease.expire(1501));assert(lease.expire(1502));assert(!lease.armed);
    assert(lease.accept({Op::ping,4},1600)==Status::ok && !lease.armed); // Ping cannot rearm.
    assert(lease.accept({Op::move,5,1},1600)==Status::disarmed);
    assert(lease.accept({Op::arm,6,1},1600)==Status::ok);
    assert(lease.accept({Op::ping,7},2000)==Status::ok);
    assert(!lease.expire(3500));assert(lease.expire(3501));
    assert(lease.accept({Op::arm,8,1},4000)==Status::ok);
    assert(lease.accept({Op::release,9},4001)==Status::ok && !lease.armed);
    lease={};lease.armed=true;lease.last_ms=std::numeric_limits<uint32_t>::max()-10;
    assert(!lease.expire(10));assert(lease.expire(1600)); // millis() rollover.
    lease={};assert(lease.accept({Op::ping,std::numeric_limits<uint32_t>::max()},0)==Status::ok);
    assert(lease.accept({Op::arm,1,1},0)==Status::stale); // Reconnect before sequence wrap.
    std::puts("protocol invariants passed: malformed packets, HID bounds, replay, arm, lease, rollover");
}
