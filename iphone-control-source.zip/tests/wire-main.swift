import Foundation
let packet=PhoneControlWire.packet(.move,sequence:0x01020304,a:-127,b:127)
precondition(Array(packet)==[76,75,1,2,4,3,2,1,129,255,127,0,0,0,0,0])
var reply=Data([76,75,1,0,4,3,2,1,42,0,0,0,1,0,0,0])
let value=PhoneControlWire.decode(reply)!
precondition(value.sequence==0x01020304 && value.boardMicroseconds==42 && value.connected && !value.armed)
precondition(PhoneControlWire.decode(Data(reply.dropLast()))==nil)
reply[14]=1;precondition(PhoneControlWire.decode(reply)==nil)
print("Swift/C++ wire fixture and malformed reply checks passed")
