import SwiftUI
import Combine

@available(iOS 27.0,*)
@MainActor final class PhoneControlSession:ObservableObject {
    static let shared=PhoneControlSession()
    let screen=PhoneScreenCapture()
    let ble=PhoneControlBLE()
    let visual:PhoneVisualAgent
    @Published var notice=""
    @Published private(set) var busy=false
    @Published private(set) var testCount=0
    @Published private(set) var visibleClickMS:Double?
    private var action:Task<Void,Never>?
    private var clickedAt:ContinuousClock.Instant?
    private var actionID=UUID()
    init() {
        visual=PhoneVisualAgent(screen:screen,ble:ble)
        screen.onUnavailable={ [weak self] in self?.cancelInput() }
        ble.onDisconnect={ [weak self] in self?.cancelInput() }
    }
    func cancelInput() {
        visual.stop()
        actionID=UUID();let old=action; action=nil;busy=false;old?.cancel();clickedAt=nil
    }
    func stop() { cancelInput();screen.stop();ble.disconnect();notice="共享和操作均已停止" }
    func measurePing() {
        guard action==nil else{return}
        busy=true;let id=UUID();actionID=id
        action=Task { [weak self] in
            guard let self else{return};defer{if self.actionID==id {self.action=nil;self.busy=false}}
            do { _=try await self.ble.send(.ping);self.notice="已收到板端回执；这不代表手机已执行点击" }
            catch {self.notice=error.localizedDescription}
        }
    }
    func move(x:Int16,y:Int16) { clickedAt=nil;perform { [ble] in _=try await ble.send(.move,a:x,b:y) } }
    func click() {
        guard action==nil else{return}
        clickedAt=ContinuousClock.now
        perform { [ble] in
            _=try await ble.send(.button,a:1,b:1)
            try await Task.sleep(for:.milliseconds(45))
            _=try await ble.send(.button,a:1,b:0)
        }
    }
    private func perform(_ operation:@escaping @MainActor () async throws -> Void) {
        guard action==nil else{return}
        busy=true;notice="";let id=UUID();actionID=id
        action=Task { [weak self] in
            guard let self else{return};defer{if self.actionID==id {self.action=nil;self.busy=false}}
            do {
                _=try self.screen.current()
                let session=self.ble.generation
                _=try await self.ble.send(.arm,a:1)
                try Task.checkCancellation()
                guard self.ble.generation==session else {throw CancellationError()}
                _=try self.screen.current()
                try await operation()
                _=try await self.ble.send(.release)
            } catch {
                if self.actionID==id {
                    self.notice=error.localizedDescription
                    self.ble.disconnect("操作已停止，请重新连接")
                }
            }
        }
    }
    func testTargetReceivedClick() {
        testCount+=1
        if let clickedAt {
            let d=clickedAt.duration(to:.now).components
            let ms=Double(d.seconds)*1000+Double(d.attoseconds)/1e15
            if ms<=800 {visibleClickMS=ms}
            self.clickedAt=nil
        }
    }
}

@available(iOS 27.0,*)
@MainActor struct PhoneControlView:View {
    @StateObject private var session=PhoneControlSession.shared
    var body:some View {
        PhoneControlPanel(session:session,screen:session.screen,ble:session.ble,visual:session.visual)
            .navigationTitle("共享屏幕与配件")
    }
}

@available(iOS 27.0,*)
@MainActor private struct PhoneControlPanel:View {
    @ObservedObject var session:PhoneControlSession
    @ObservedObject var screen:PhoneScreenCapture
    @ObservedObject var ble:PhoneControlBLE
    @ObservedObject var visual:PhoneVisualAgent
    var body:some View {
        ScrollView {
            VStack(alignment:.leading,spacing:18) {
                Text("让 Loki 看你共享的屏幕，通过配件执行操作。你可以随时停止。")
                    .font(.subheadline).foregroundStyle(.secondary)
                HStack {
                    Button("共享整个屏幕") {screen.start()}.buttonStyle(.borderedProminent)
                    Button("全部停止",role:.destructive) {session.stop()}.buttonStyle(.bordered)
                }
                Text(screen.state).font(.caption)
                if let frame=screen.frame {
                    Image(uiImage:frame.image).resizable().scaledToFit().frame(maxHeight:260)
                        .clipShape(RoundedRectangle(cornerRadius:16))
                    TimelineView(.periodic(from:.now,by:0.25)) { context in
                        Text(String(format:"画面确认距今 %.0f 毫秒",max(0,context.date.timeIntervalSince(frame.confirmedAt)*1000)))
                            .font(.caption).monospacedDigit()
                    }
                }
                Divider()
                Text("配件连接").font(.headline)
                Text("先在设置 → 辅助功能 → 触控 → 辅助触控 → 设备中配对 Loki S3 Control，然后回到这里连接。")
                    .font(.caption).foregroundStyle(.secondary)
                HStack {
                    Button("连接配件") {ble.connect()}.disabled(ble.ready)
                    Button("测试指令往返") {session.measurePing()}.disabled(!ble.ready || session.busy || visual.running)
                }.buttonStyle(.bordered)
                Text(ble.state).font(.caption)
                if let ms=ble.roundTripMS {Text(String(format:"指令往返 %.1f 毫秒",ms)).monospacedDigit()}
                Divider()
                Text("让 Loki 操作").font(.headline)
                TextField("希望 Loki 完成什么？",text:$visual.goal,axis:.vertical)
                    .textFieldStyle(.roundedBorder).disabled(visual.running)
                Text("开始后有 5 秒可切换页面。Loki 会逐步查看画面并操作；需要你处理的提示会停下来说明。")
                    .font(.caption).foregroundStyle(.secondary)
                HStack {
                    Button("开始任务") {visual.start()}.disabled(visual.running || !ble.ready || !screen.active || session.busy)
                    Button("只看屏幕") {visual.start(observeOnly:true)}.disabled(visual.running || !screen.active || session.busy)
                    Button("停止任务",role:.destructive) {visual.stop()}.disabled(!visual.running)
                }.buttonStyle(.bordered)
                Text(visual.status).font(.callout).textSelection(.enabled)
                if let ms=visual.decisionMS {Text(String(format:"画面判断 %.0f 毫秒 · 已执行 %d 步",ms,visual.completedSteps)).font(.caption).monospacedDigit()}
                Divider()
                Text("本机点击测试").font(.headline)
                Text("共享屏幕后，用方向键将鼠标光标移到下方测试区，再点“单击”。测量时请勿用手指触摸测试区。")
                    .font(.caption).foregroundStyle(.secondary)
                Button {session.testTargetReceivedClick()} label: {
                    VStack {Text("点击测试区").font(.headline);Text("收到 \(session.testCount) 次点击")}
                        .frame(maxWidth:.infinity,minHeight:100)
                }.buttonStyle(.borderedProminent)
                HStack {
                    Button("←") {session.move(x:-25,y:0)}
                    Button("↑") {session.move(x:0,y:-25)}
                    Button("↓") {session.move(x:0,y:25)}
                    Button("→") {session.move(x:25,y:0)}
                    Button("单击") {session.click()}
                }.buttonStyle(.bordered).disabled(!ble.ready || !screen.active || session.busy || visual.running)
                if let ms=session.visibleClickMS {Text(String(format:"测试区响应：%.1f 毫秒（仅配件点击时有效）",ms)).monospacedDigit()}
                Text("指令往返、手机收到点击和模型判断是三项不同耗时。本页先验证前两项。")
                    .font(.caption).foregroundStyle(.secondary)
                if !session.notice.isEmpty {Text(session.notice).font(.caption)}
            }.padding()
        }
    }
}
