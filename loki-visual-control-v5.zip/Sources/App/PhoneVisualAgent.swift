import Foundation
import Combine
import CryptoKit
import UIKit

struct PhoneVisualDecision: Decodable {
    let action:String
    let dx:Int; let dy:Int; let wheel:Int
    let cursor_visible:Bool
    let cursor_x:Double; let cursor_y:Double
    let target_left:Double; let target_top:Double; let target_right:Double; let target_bottom:Double
    let needs_confirmation:Bool
    let message:String
    func validate(observeOnly:Bool) throws {
        guard ["observe","move","click","scroll","done","ask"].contains(action),
              (-40...40).contains(dx),(-40...40).contains(dy),(-3...3).contains(wheel),message.count<=1200,
              [cursor_x,cursor_y,target_left,target_top,target_right,target_bottom].allSatisfy({$0.isFinite && (0...1).contains($0)}),
              (!observeOnly || action=="observe"),
              (!needs_confirmation || action=="ask" || action=="observe"),
              (action=="move" || (dx==0 && dy==0)),(action=="scroll" || wheel==0)
        else {throw PhoneControlFailure.message("操作结果未通过验证，已停止")}
        if ["move","click","scroll"].contains(action) && !cursor_visible {
            throw PhoneControlFailure.message("画面中看不到鼠标指针，请先让指针显示")
        }
        if action=="click" {
            guard target_left<cursor_x,cursor_x<target_right,target_top<cursor_y,cursor_y<target_bottom,
                  target_right-target_left>=0.005,target_bottom-target_top>=0.005 else {
                throw PhoneControlFailure.message("指针未到达目标，已停止点击")
            }
        }
    }
}
struct PhoneVisualReply:Decodable {
    let session:String;let request_id:String;let step:Int;let fingerprint:String
    let decision:PhoneVisualDecision;let decision_ms:Double
}

@available(iOS 27.0,*)
@MainActor final class PhoneVisualAgent:ObservableObject {
    @Published var goal=""
    @Published private(set) var running=false
    @Published private(set) var status="填写当前目标，再开始操作"
    @Published private(set) var decisionMS:Double?
    @Published private(set) var completedSteps=0
    private let screen:PhoneScreenCapture
    private let ble:PhoneControlBLE
    private var task:Task<Void,Never>?
    private var generation=UUID()
    private var session:UUID?
    private var backgroundTask:UIBackgroundTaskIdentifier = .invalid
    init(screen:PhoneScreenCapture,ble:PhoneControlBLE) {self.screen=screen;self.ble=ble}
    private var api:MobileAPI {
        MobileAPI(base:UserDefaults.standard.string(forKey:"gatewayURL") ?? "",token:SecureToken.read())
    }
    func stop() {
        let previous=session;session=nil;generation=UUID();let old=task;task=nil
        let wasRunning=running;running=false;old?.cancel()
        endTransitionTime()
        if wasRunning {status="操作已停止"}
        if let previous {
            let client=api
            Task { _ = try? await client.data("/v1/phone-control/stop",["session":previous.uuidString],timeout:5) }
        }
    }
    func start(observeOnly:Bool=false) {
        guard !running else{return}
        let target=goal.trimmingCharacters(in:.whitespacesAndNewlines)
        guard observeOnly || !target.isEmpty else {status="请先填写你希望 Loki 完成的事情";return}
        guard observeOnly || ble.ready else {status="请先连接配件";return}
        do {_=try screen.current()} catch {status=error.localizedDescription;return}
        let id=UUID();generation=id;session=id;running=true;completedSteps=0;decisionMS=nil
        backgroundTask=UIApplication.shared.beginBackgroundTask(withName:"LokiScreenControlTransition") { [weak self] in
            Task { @MainActor in self?.endTransitionTime() }
        }
        let client=api
        task=Task { [weak self] in
            guard let self else{return}
            defer {if self.generation==id {self.running=false;self.task=nil;self.session=nil;self.endTransitionTime()}}
            do {
                for seconds in stride(from:5,through:1,by:-1) {
                    self.status="\(seconds) 秒后开始，请切换到要操作的页面"
                    try await Task.sleep(for:.seconds(1))
                }
                var changedFrames=0
                for step in 0..<16 {
                    try Task.checkCancellation()
                    guard self.generation==id else {throw CancellationError()}
                    let frame=try await self.waitForFrame()
                    var jpeg=frame.jpeg
                    if jpeg.count>155_000 {
                        for quality in [0.5,0.35,0.2] {
                            if let smaller=frame.image.jpegData(compressionQuality:quality) {jpeg=smaller}
                            if jpeg.count<=155_000 {break}
                        }
                    }
                    guard jpeg.count<=155_000 else {throw PhoneControlFailure.message("画面过大，请等待页面稳定后再开始")}
                    let fingerprint=SHA256.hash(data:jpeg).map {String(format:"%02x",$0)}.joined()
                    let request=UUID();self.status="Loki 正在看屏幕…"
                    let body:[String:Any]=["session":id.uuidString,"request_id":request.uuidString,"step":step,
                        "goal":observeOnly ? "描述当前屏幕，指出可以操作的控件" : target,
                        "observe_only":observeOnly,"jpeg":jpeg.base64EncodedString(),"fingerprint":fingerprint]
                    let raw=try await client.data("/v1/phone-control/step",body,timeout:115)
                    try Task.checkCancellation()
                    let reply=try JSONDecoder().decode(PhoneVisualReply.self,from:raw)
                    guard self.generation==id,UUID(uuidString:reply.session)==id,
                          UUID(uuidString:reply.request_id)==request,reply.step==step,reply.fingerprint==fingerprint else {
                        throw PhoneControlFailure.message("画面或任务不匹配，已停止")
                    }
                    try reply.decision.validate(observeOnly:observeOnly)
                    self.decisionMS=reply.decision_ms;self.status=reply.decision.message
                    if ["observe","done","ask"].contains(reply.decision.action) {return}
                    let current=try await self.waitForFrame()
                    guard current.session==frame.session else {
                        throw PhoneControlFailure.message("共享已改变，已停止")
                    }
                    guard PhoneFrameConsistency.matches(frame.image,current.image,decision:reply.decision) else {
                        changedFrames+=1
                        guard changedFrames<=3 else {throw PhoneControlFailure.message("页面持续变化，请稳定页面后再开始")}
                        self.status="页面已变化，重新查看后再操作";continue
                    }
                    try await self.execute(reply.decision,frame:frame,id:id)
                    changedFrames=0
                    self.completedSteps+=1
                    try await Task.sleep(for:.milliseconds(350))
                }
                self.status="本轮已达到 16 步，请查看进展后重新开始"
            } catch is CancellationError {
                if self.generation==id {self.status="操作已停止"}
            } catch {
                if self.generation==id {self.status=error.localizedDescription}
            }
        }
    }
    private func endTransitionTime() {
        if backgroundTask != .invalid {UIApplication.shared.endBackgroundTask(backgroundTask);backgroundTask = .invalid}
    }
    private func waitForFrame() async throws -> PhoneScreenFrame {
        let deadline=ContinuousClock.now.advanced(by:.seconds(8))
        while ContinuousClock.now<deadline {
            try Task.checkCancellation()
            if let frame=try? screen.current() {return frame}
            status="等待切换后的新画面…"
            try await Task.sleep(for:.milliseconds(150))
        }
        throw PhoneControlFailure.message("暂未收到新画面，请检查系统屏幕共享是否仍在进行")
    }
    private func execute(_ decision:PhoneVisualDecision,frame:PhoneScreenFrame,id:UUID) async throws {
        do {
            let connection=ble.generation
            _=try await ble.send(.arm,a:1)
            try Task.checkCancellation()
            let latest=try screen.current()
            guard generation==id,ble.generation==connection,latest.session==frame.session,
                  PhoneFrameConsistency.matches(frame.image,latest.image,decision:decision) else {throw PhoneControlFailure.message("操作目标已变化，已停止")}
            switch decision.action {
            case "move": _=try await ble.send(.move,a:Int16(decision.dx),b:Int16(decision.dy))
            case "scroll": _=try await ble.send(.move,c:Int16(decision.wheel))
            case "click":
                _=try await ble.send(.button,a:1,b:1)
                try await Task.sleep(for:.milliseconds(45))
                _=try await ble.send(.button,a:1,b:0)
            default: throw PhoneControlFailure.message("未知操作，已停止")
            }
            _=try await ble.send(.release)
        } catch {ble.disconnect("操作已停止，请重新连接配件");throw error}
    }
}
