import Foundation

private final class PhoneAgentNoRedirect:NSObject,URLSessionTaskDelegate {
    func urlSession(_ session:URLSession,task:URLSessionTask,willPerformHTTPRedirection response:HTTPURLResponse,
                    newRequest request:URLRequest,completionHandler:@escaping (URLRequest?)->Void) {
        completionHandler(nil)
    }
}

struct PhoneAgentJob:Decodable {
    let state:String
    let request_id:String
    let reply:PhoneVisualReply?
    let error:String?
}
struct PhoneAgentHTTP:LocalizedError {
    let status:Int
    var errorDescription:String? {"手机控制接口 HTTP \(status)，未重复提交操作"}
}
struct PhoneAgentTransport {
    private static let session:URLSession = {
        let config=URLSessionConfiguration.ephemeral
        config.urlCache=nil;config.waitsForConnectivity=false
        return URLSession(configuration:config,delegate:PhoneAgentNoRedirect(),delegateQueue:nil)
    }()
    func data(_ path:String,body:[String:Any]?=nil,timeout:Double=8) async throws -> Data {
        let base=UserDefaults.standard.string(forKey:"gatewayURL") ?? ""
        let token=SecureToken.read()
        guard let parts=URLComponents(string:base),parts.scheme=="https",parts.host != nil,
              parts.user==nil,parts.password==nil,parts.query==nil,parts.fragment==nil,
              parts.path.isEmpty || parts.path=="/",token.count>=32,
              let url=URL(string:base.trimmingCharacters(in:CharacterSet(charactersIn:"/"))+path) else {
            throw PhoneControlFailure.message("请先配置 Loki 私有连接")
        }
        var request=URLRequest(url:url,cachePolicy:.reloadIgnoringLocalCacheData,timeoutInterval:timeout)
        request.setValue("Bearer "+token,forHTTPHeaderField:"Authorization")
        if let body {
            request.httpMethod="POST";request.setValue("application/json",forHTTPHeaderField:"Content-Type")
            request.httpBody=try JSONSerialization.data(withJSONObject:body)
        }
        let (data,response)=try await Self.session.data(for:request)
        guard let http=response as? HTTPURLResponse else {throw PhoneControlFailure.message("控制接口没有返回 HTTP 响应")}
        guard (200..<300).contains(http.statusCode) else {throw PhoneAgentHTTP(status:http.statusCode)}
        return data
    }
    func decide(_ body:[String:Any],request:UUID) async throws -> PhoneVisualReply {
        var accepted=false
        do {
            let raw=try await data("/v1/phone-autonomy/submit",body:body,timeout:12)
            let job=try JSONDecoder().decode(PhoneAgentJob.self,from:raw)
            guard UUID(uuidString:job.request_id)==request else {throw PhoneControlFailure.message("任务编号不匹配")}
            accepted=true
        } catch let error as PhoneAgentHTTP where (400..<500).contains(error.status) {throw error}
        catch is CancellationError {throw CancellationError()}
        catch { /* Resolve a lost submission response through read-only polling. */ }
        let deadline=ContinuousClock.now.advanced(by:.seconds(115))
        let receiptDeadline=ContinuousClock.now.advanced(by:.seconds(12))
        var lastError:Error?
        while ContinuousClock.now<deadline {
            try Task.checkCancellation()
            do {
                let raw=try await data("/v1/phone-autonomy/result/"+request.uuidString,timeout:7)
                let job=try JSONDecoder().decode(PhoneAgentJob.self,from:raw)
                guard UUID(uuidString:job.request_id)==request else {throw PhoneControlFailure.message("任务编号不匹配")}
                accepted=true
                if job.state=="complete",let reply=job.reply {return reply}
                if job.state=="failed" {throw PhoneControlFailure.message("画面判断未完成；未执行或重发该步操作")}
                guard job.state=="pending" else {throw PhoneControlFailure.message("任务状态异常")}
            } catch let error as PhoneAgentHTTP {
                if error.status==401 || error.status==403 {throw error}
                if error.status==404 && (accepted || ContinuousClock.now>receiptDeadline) {throw error}
                lastError=error
            } catch let error as PhoneControlFailure {throw error}
            catch is CancellationError {throw CancellationError()}
            catch {lastError=error}
            try await Task.sleep(for:.milliseconds(650))
        }
        throw lastError ?? PhoneControlFailure.message("画面判断超时；未重复提交")
    }
    func stop(_ session:UUID) async {
        _=try? await data("/v1/phone-autonomy/stop",body:["session":session.uuidString],timeout:5)
    }
}
