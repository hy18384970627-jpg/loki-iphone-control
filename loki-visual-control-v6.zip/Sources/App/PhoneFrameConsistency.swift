import UIKit

// JPEG hashes identify requests; they are not a useful UI stability metric.
// Compare scene pixels and, for clicks, separately require the cursor/target
// neighborhoods to remain stable. The status bar and home indicator are excluded.
enum PhoneFrameConsistency {
    private struct Raster {let width:Int;let height:Int;let bytes:[UInt8]}
    private static func raster(_ image:UIImage)->Raster? {
        guard let source=image.cgImage,source.width>0,source.height>0 else{return nil}
        let width=256,height=max(1,Int(Double(source.height)*256/Double(source.width)))
        guard height<=1024 else{return nil}
        var bytes=[UInt8](repeating:0,count:width*height*4)
        let success=bytes.withUnsafeMutableBytes { buffer -> Bool in
            guard let context=CGContext(data:buffer.baseAddress,width:width,height:height,bitsPerComponent:8,
                bytesPerRow:width*4,space:CGColorSpaceCreateDeviceRGB(),
                bitmapInfo:CGImageAlphaInfo.premultipliedLast.rawValue|CGBitmapInfo.byteOrder32Big.rawValue) else{return false}
            context.interpolationQuality = .low
            context.draw(source,in:CGRect(x:0,y:0,width:width,height:height))
            return true
        }
        return success ? Raster(width:width,height:height,bytes:bytes) : nil
    }
    private static func similar(_ a:Raster,_ b:Raster,rect:CGRect,allowedFraction:Double,allowedMean:Double)->Bool {
        let left=max(0,Int(rect.minX*Double(a.width))),right=min(a.width,Int(ceil(rect.maxX*Double(a.width))))
        let top=max(0,Int(rect.minY*Double(a.height))),bottom=min(a.height,Int(ceil(rect.maxY*Double(a.height))))
        guard left<right,top<bottom else{return false}
        var changed=0,total=0,error=0
        for y in top..<bottom {for x in left..<right {
            let i=(y*a.width+x)*4
            let delta=abs(Int(a.bytes[i])-Int(b.bytes[i]))+abs(Int(a.bytes[i+1])-Int(b.bytes[i+1]))+abs(Int(a.bytes[i+2])-Int(b.bytes[i+2]))
            if delta>90 {changed+=1};error+=delta;total+=1
        }}
        return Double(changed)/Double(total)<=allowedFraction && Double(error)/Double(total*3)<=allowedMean
    }
    static func matches(_ old:UIImage,_ current:UIImage,decision:PhoneVisualDecision)->Bool {
        guard let a=raster(old),let b=raster(current),a.width==b.width,a.height==b.height else{return false}
        guard similar(a,b,rect:CGRect(x:0,y:0.06,width:1,height:0.90),allowedFraction:0.025,allowedMean:4) else{return false}
        guard ["click","drag","long_press","type_text","key"].contains(decision.action) else{return true}
        let target=CGRect(x:decision.target_left,y:decision.target_top,
            width:decision.target_right-decision.target_left,height:decision.target_bottom-decision.target_top).insetBy(dx:-0.015,dy:-0.015)
        let cursor=CGRect(x:decision.cursor_x-0.035,y:decision.cursor_y-0.035,width:0.07,height:0.07)
        return similar(a,b,rect:target,allowedFraction:0.005,allowedMean:2) &&
            similar(a,b,rect:cursor,allowedFraction:0.005,allowedMean:2)
    }
}
