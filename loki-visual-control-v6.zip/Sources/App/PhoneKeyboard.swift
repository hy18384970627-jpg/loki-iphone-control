import Foundation

// Every key edge is acknowledged. The lease heartbeat never races a key write.
@MainActor final class PhoneKeyboard {
    let ble:PhoneControlBLE
    var heartbeat=ContinuousClock.now
    init(_ ble:PhoneControlBLE) {self.ble=ble}
    func keepAlive() async throws {
        try Task.checkCancellation()
        if heartbeat.duration(to:.now) > .milliseconds(400) {
            _=try await ble.send(.ping);heartbeat = .now
        }
    }
    func press(_ usage:Int16,_ modifiers:[Int16]=[]) async throws {
        try await keepAlive()
        for modifier in modifiers {_=try await ble.send(.key,a:modifier,b:1)}
        _=try await ble.send(.key,a:usage,b:1)
        try await Task.sleep(for:.milliseconds(25))
        _=try await ble.send(.key,a:usage,b:0)
        for modifier in modifiers.reversed() {_=try await ble.send(.key,a:modifier,b:0)}
    }
    func type(_ text:String) async throws {
        guard !text.isEmpty,text.count<=160,text.utf8.allSatisfy({(32...126).contains($0)}) else {
            throw PhoneControlFailure.message("仅允许输入英文文本")
        }
        for byte in text.utf8 {
            let (usage,shift)=try Self.mapping(byte)
            try await press(usage,shift ? [225] : [])
        }
    }
    static func mapping(_ byte:UInt8) throws -> (Int16,Bool) {
        if (97...122).contains(byte) {return (Int16(byte-97)+4,false)}
        if (65...90).contains(byte) {return (Int16(byte-65)+4,true)}
        if (49...57).contains(byte) {return (Int16(byte-49)+30,false)}
        let pairs:[UInt8:(Int16,Bool)]=[
            48:(39,false),32:(44,false),45:(45,false),95:(45,true),61:(46,false),43:(46,true),
            91:(47,false),123:(47,true),93:(48,false),125:(48,true),92:(49,false),124:(49,true),
            59:(51,false),58:(51,true),39:(52,false),34:(52,true),96:(53,false),126:(53,true),
            44:(54,false),60:(54,true),46:(55,false),62:(55,true),47:(56,false),63:(56,true),
            33:(30,true),64:(31,true),35:(32,true),36:(33,true),37:(34,true),94:(35,true),
            38:(36,true),42:(37,true),40:(38,true),41:(39,true)]
        guard let mapped=pairs[byte] else {throw PhoneControlFailure.message("无法输入该字符")}
        return mapped
    }
    func key(_ name:String) async throws {
        let keys:[String:Int16]=["enter":40,"escape":41,"backspace":42,"tab":43,"space":44,
            "right":79,"left":80,"down":81,"up":82]
        if let code=keys[name] {try await press(code);return}
        switch name {
        case "select_all":try await press(4,[227])
        case "search":try await press(44,[227])
        case "app_switcher":try await press(43,[227])
        case "switch_keyboard":try await press(44,[224])
        case "shift_enter":try await press(40,[225])
        default:throw PhoneControlFailure.message("未知快捷键")
        }
    }
    func home() async throws {
        try await keepAlive()
        _=try await ble.send(.consumer,a:547,b:1)
        try await Task.sleep(for:.milliseconds(45))
        _=try await ble.send(.consumer,a:547,b:0)
    }
    func hold(milliseconds:Int) async throws {
        for _ in 0..<max(1,milliseconds/50) {
            try await keepAlive();try await Task.sleep(for:.milliseconds(50))
        }
    }
    func drag(dx:Int,dy:Int) async throws {
        let count=max(1,Int(ceil(Double(max(abs(dx),abs(dy)))/25)))
        var x=0,y=0
        for i in 1...count {
            let nextX=dx*i/count,nextY=dy*i/count
            try await keepAlive()
            _=try await ble.send(.move,a:Int16(nextX-x),b:Int16(nextY-y));x=nextX;y=nextY
            try await Task.sleep(for:.milliseconds(25))
        }
    }
}
