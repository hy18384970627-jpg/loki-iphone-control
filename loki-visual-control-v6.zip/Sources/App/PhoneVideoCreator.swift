import Foundation
import UIKit
import AVFoundation
import Photos

// Original English caption cards + the already-configured Loki voice.
// Saving an asset is distinct from uploading or publishing it in another app.
@MainActor enum PhoneVideoCreator {
    static func preparePhotos() async -> Bool {
        let status=await PHPhotoLibrary.requestAuthorization(for:.addOnly)
        return status == .authorized || status == .limited
    }
    static func create(title:String,script:String) async throws -> String {
        guard (80...1400).contains(script.count),(script+title).unicodeScalars.allSatisfy({$0.value<=126}),
              PHPhotoLibrary.authorizationStatus(for:.addOnly) == .authorized else {
            throw PhoneControlFailure.message("请先回 Loki 允许保存创作视频，并确认英文脚本")
        }
        let folder=FileManager.default.temporaryDirectory.appendingPathComponent("LokiVideo-"+UUID().uuidString)
        try FileManager.default.createDirectory(at:folder,withIntermediateDirectories:true)
        defer {try? FileManager.default.removeItem(at:folder)}
        let audio=folder.appendingPathComponent("voice.wav")
        let silent=folder.appendingPathComponent("cards.mp4")
        let output=folder.appendingPathComponent("Loki-original.mp4")
        var pcm=Data()
        let api=MobileAPI(base:UserDefaults.standard.string(forKey:"gatewayURL") ?? "",token:SecureToken.read())
        try await api.speech(script) {chunk in
            guard pcm.count+chunk.count<=24_000*2*120 else {throw PhoneControlFailure.message("创作旁白过长")}
            pcm.append(chunk)
        }
        try Task.checkCancellation()
        guard pcm.count>=4800,pcm.count.isMultiple(of:2) else {throw PhoneControlFailure.message("没有取得完整旁白")}
        var wav=Data("RIFF".utf8)
        func u32(_ value:UInt32) {var le=value.littleEndian;withUnsafeBytes(of:&le) {wav.append(contentsOf:$0)}}
        func u16(_ value:UInt16) {var le=value.littleEndian;withUnsafeBytes(of:&le) {wav.append(contentsOf:$0)}}
        u32(UInt32(36+pcm.count));wav.append(Data("WAVEfmt ".utf8));u32(16);u16(1);u16(1)
        u32(24000);u32(48000);u16(2);u16(16);wav.append(Data("data".utf8));u32(UInt32(pcm.count));wav.append(pcm)
        try wav.write(to:audio);let seconds=Double(pcm.count)/48000;pcm.removeAll();wav.removeAll()
        var cards=[String](),line=""
        for word in script.split(whereSeparator:{$0.isWhitespace}) {
            if line.count+word.count+1>160 {cards.append(line);line=""}
            line += (line.isEmpty ? "" : " ")+word
        }
        if !line.isEmpty {cards.append(line)}
        let writer=try AVAssetWriter(outputURL:silent,fileType:.mp4)
        let input=AVAssetWriterInput(mediaType:.video,outputSettings:[AVVideoCodecKey:AVVideoCodecType.h264,
            AVVideoWidthKey:720,AVVideoHeightKey:1280])
        let adapter=AVAssetWriterInputPixelBufferAdaptor(assetWriterInput:input,sourcePixelBufferAttributes:[
            kCVPixelBufferPixelFormatTypeKey as String:kCVPixelFormatType_32ARGB,
            kCVPixelBufferWidthKey as String:720,kCVPixelBufferHeightKey as String:1280,
            kCVPixelBufferCGImageCompatibilityKey as String:true,kCVPixelBufferCGBitmapContextCompatibilityKey as String:true])
        guard writer.canAdd(input) else {throw PhoneControlFailure.message("无法创建视频编码器")}
        writer.add(input);guard writer.startWriting() else {throw PhoneControlFailure.message("视频编码未启动")}
        writer.startSession(atSourceTime:.zero)
        do {
            let frames=max(2,Int(ceil(seconds*2)))
            for index in 0..<frames {
                try Task.checkCancellation()
                let until=ContinuousClock.now.advanced(by:.seconds(10))
                while !input.isReadyForMoreMediaData {
                    try Task.checkCancellation()
                    guard writer.status == .writing,ContinuousClock.now<until else {throw PhoneControlFailure.message("视频编码暂停或失败")}
                    try await Task.sleep(for:.milliseconds(10))
                }
                let page=min(cards.count-1,index*cards.count/frames)
                let image=card(title:title,text:cards[page],page:page+1,total:cards.count)
                guard let pool=adapter.pixelBufferPool else {throw PhoneControlFailure.message("视频像素池不可用")}
                var result:CVPixelBuffer?
                guard CVPixelBufferPoolCreatePixelBuffer(nil,pool,&result)==kCVReturnSuccess,let buffer=result else {
                    throw PhoneControlFailure.message("视频帧创建失败")
                }
                CVPixelBufferLockBaseAddress(buffer,[])
                let context=CGContext(data:CVPixelBufferGetBaseAddress(buffer),width:720,height:1280,bitsPerComponent:8,
                    bytesPerRow:CVPixelBufferGetBytesPerRow(buffer),space:CGColorSpaceCreateDeviceRGB(),
                    bitmapInfo:CGImageAlphaInfo.noneSkipFirst.rawValue)
                context?.draw(image,in:CGRect(x:0,y:0,width:720,height:1280))
                CVPixelBufferUnlockBaseAddress(buffer,[])
                guard context != nil,adapter.append(buffer,withPresentationTime:CMTime(value:Int64(index),timescale:2)) else {
                    throw PhoneControlFailure.message("视频帧写入失败")
                }
                await Task.yield()
            }
            writer.endSession(atSourceTime:CMTime(seconds:seconds,preferredTimescale:600));input.markAsFinished()
            await writer.finishWriting()
            guard writer.status == .completed else {throw PhoneControlFailure.message("视频编码未完成")}
        } catch {writer.cancelWriting();throw error}
        let composition=AVMutableComposition()
        let videoAsset=AVURLAsset(url:silent),audioAsset=AVURLAsset(url:audio)
        guard let video=try await videoAsset.loadTracks(withMediaType:.video).first,
              let voice=try await audioAsset.loadTracks(withMediaType:.audio).first,
              let v=composition.addMutableTrack(withMediaType:.video,preferredTrackID:kCMPersistentTrackID_Invalid),
              let a=composition.addMutableTrack(withMediaType:.audio,preferredTrackID:kCMPersistentTrackID_Invalid),
              let exporter=AVAssetExportSession(asset:composition,presetName:AVAssetExportPresetHighestQuality) else {
            throw PhoneControlFailure.message("视频合成轨道不可用")
        }
        let range=CMTimeRange(start:.zero,duration:CMTime(seconds:seconds,preferredTimescale:600))
        try v.insertTimeRange(range,of:video,at:.zero);try a.insertTimeRange(range,of:voice,at:.zero)
        try await withTaskCancellationHandler(operation:{try await exporter.export(to:output,as:.mp4)},onCancel:{exporter.cancelExport()})
        try Task.checkCancellation()
        try await PHPhotoLibrary.shared().performChanges {
            PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL:output)
        }
        return String(format:"Original English Loki caption-card video saved to Photos: %.1f seconds, title '%@'. It has NOT been uploaded or published. Inspect the social app's recent-video picker.",seconds,title)
    }
    private static func card(title:String,text:String,page:Int,total:Int)->CGImage {
        let format=UIGraphicsImageRendererFormat();format.scale=1
        let image=UIGraphicsImageRenderer(size:CGSize(width:720,height:1280),format:format).image { context in
            UIColor(red:0.025,green:0.08,blue:0.07,alpha:1).setFill();context.fill(CGRect(x:0,y:0,width:720,height:1280))
            UIImage(named:"ChatWallpaper")?.draw(in:CGRect(x:0,y:0,width:720,height:1280),blendMode:.normal,alpha:0.3)
            UIColor.black.withAlphaComponent(0.45).setFill();context.fill(CGRect(x:0,y:0,width:720,height:1280))
            let paragraph=NSMutableParagraphStyle();paragraph.alignment = .left;paragraph.lineSpacing=12
            func draw(_ string:String,_ rect:CGRect,_ font:UIFont,_ color:UIColor) {
                (string as NSString).draw(in:rect,withAttributes:[.font:font,.foregroundColor:color,.paragraphStyle:paragraph])
            }
            draw("LOKI",CGRect(x:56,y:94,width:600,height:70),.systemFont(ofSize:36,weight:.semibold),.systemYellow)
            draw(title,CGRect(x:56,y:200,width:608,height:190),.systemFont(ofSize:42,weight:.semibold),.white)
            draw(text,CGRect(x:56,y:430,width:608,height:660),.systemFont(ofSize:38,weight:.regular),.white)
            draw("\(page) / \(total)",CGRect(x:56,y:1160,width:600,height:50),.systemFont(ofSize:22),.lightGray)
        }
        return image.cgImage!
    }
}
