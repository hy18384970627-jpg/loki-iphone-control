import Foundation
import Combine
import CryptoKit
import UIKit

struct PhoneVisualDecision:Decodable {
    let action:String
    let dx:Int;let dy:Int;let wheel:Int
    let cursor_visible:Bool
    let cursor_x:Double;let cursor_y:Double
    let target_left:Double;let target_top:Double;let target_right:Double;let target_bottom:Double
    let needs_confirmation:Bool
    let message:String;let text:String;let key:String;let duration_ms:Int
    let source_url:String;let title:String;let intent:String;let observation:String
    func validate(observeOnly:Bool) throws {
        let actions=["observe","move","click","scroll","home","open_app","type_text","key","drag","long_press","wait","note","create_video","done","ask"]
        let keys=["","enter","escape","backspace","tab","space","left","right","up","down","select_all","search","app_switcher","switch_keyboard","shift_enter"]
        guard actions.contains(action),keys.contains(key),(-500...500).contains(dx),(-500...500).contains(dy),
              (-5...5).contains(wheel),(0...5000).contains(duration_ms),message.count<=1200,text.count<=2400,
              [cursor_x,cursor_y,target_left,target_top,target_right,target_bottom].allSatisfy({$0.isFinite && (0...1).contains($0)}),
              (!observeOnly || action=="observe"),(!needs_confirmation || action=="ask"),
              (["move","drag"].contains(action) || (dx==0 && dy==0)),(action=="scroll" || wheel==0),
              (text+title).unicodeScalars.allSatisfy({$0.value<=126 && ($0.value>=32 || [9,10,13].contains($0.value))})
        else {throw PhoneControlFailure.message("操作或英文内容未通过校验")}
        if ["move","click","scroll","drag","long_press"].contains(action),!cursor_visible {
            throw PhoneControlFailure.message("画面中看不到指针，请先让指针显示")
        }
        if ["click","drag","long_press"].contains(action) {
            guard target_left<cursor_x,cursor_x<target_right,target_top<cursor_y,cursor_y<target_bottom,
                  target_right-target_left>=0.005,target_bottom-target_top>=0.005 else {
                throw PhoneControlFailure.message("指针未到达目标，已停止点击")
            }
        }
        if action=="move",abs(dx)>80 || abs(dy)>80 {throw PhoneControlFailure.message("指针移动过大")}
        if ["type_text","open_app"].contains(action) {
            guard !text.isEmpty,text.count<=160,text.utf8.allSatisfy({(32...126).contains($0)}) else {
                throw PhoneControlFailure.message("待输入内容必须为英文")
            }
        }
        if action=="type_text" || (action=="key" && !["search","app_switcher","switch_keyboard","escape"].contains(key)) {
            guard target_left<target_right,target_top<target_bottom else {throw PhoneControlFailure.message("未确认可输入的目标")}
        }
        if action=="long_press",!(500...1200).contains(duration_ms) {throw PhoneControlFailure.message("长按时长异常")}
        if action=="create_video",!(80...1400).contains(text.count) {throw PhoneControlFailure.message("英文视频脚本长度异常")}
    }
}
struct PhoneVisualReply:Decodable {
    let session:String;let request_id:String;let step:Int;let fingerprint:String
    let decision:PhoneVisualDecision;let decision_ms:Double
}

@available(iOS 27.0,*)
@MainActor final class PhoneVisualAgent:ObservableObject {
    @Published var goal=""
    @Published private(set) var running=false
    @Published private(set) var status="可以交给 Loki 自己逛逛，也可以给他一个目标"
    @Published private(set) var intention=""
    @Published private(set) var findings:[String]=[]
    @Published private(set) var decisionMS:Double?
    @Published private(set) var completedSteps=0
    private let screen:PhoneScreenCapture
    private let ble:PhoneControlBLE
    private var task:Task<Void,Never>?
    private var generation=UUID()
    private var session:UUID?
    private var backgroundTask:UIBackgroundTaskIdentifier = .invalid
    init(screen:PhoneScreenCapture,ble:PhoneControlBLE) {self.screen=screen;self.ble=ble}
    func stop() {
        let previous=session;session=nil;generation=UUID();let old=task;task=nil
        let wasRunning=running;running=false;old?.cancel();endTransitionTime()
        if wasRunning {status="操作已停止"}
        if let previous {Task {await PhoneAgentTransport().stop(previous)}}
    }
    func start(observeOnly:Bool=false,roam:Bool=false) {
        guard !running else{return}
        let target=goal.trimmingCharacters(in:.whitespacesAndNewlines)
        guard observeOnly || roam || !target.isEmpty else {status="请填写目标，或选择让 Loki 自己逛逛";return}
        guard observeOnly || ble.ready else {status="请先连接配件";return}
        do {_=try screen.current()} catch {status=error.localizedDescription;return}
        let id=UUID();generation=id;session=id;running=true;completedSteps=0;decisionMS=nil;intention=""
        backgroundTask=UIApplication.shared.beginBackgroundTask(withName:"LokiScreenControlTransition") { [weak self] in
            Task { @MainActor in self?.endTransitionTime() }
        }
        task=Task { [weak self] in
            guard let self else{return}
            defer {if self.generation==id {self.running=false;self.task=nil;self.session=nil;self.endTransitionTime()}}
            do {
                for seconds in stride(from:5,through:1,by:-1) {
                    self.status="\(seconds) 秒后开始，可以切换到其他 App"
                    try await Task.sleep(for:.seconds(1))
                }
                var previous:[String:Any]?
                var changedFrames=0
                for step in 0..<160 {
                    try Task.checkCancellation()
                    guard self.generation==id else {throw CancellationError()}
                    let frame=try await self.waitForFrame()
                    let jpeg=try self.compressed(frame.image)
                    let fingerprint=SHA256.hash(data:jpeg).map {String(format:"%02x",$0)}.joined()
                    let request=UUID();self.status="Loki 正在看屏幕…"
                    var body:[String:Any]=["session":id.uuidString,"request_id":request.uuidString,"step":step,
                        "goal":observeOnly ? "Describe the current screen." : (roam ? "" : target),
                        "mode":observeOnly ? "observe" : (roam ? "roam" : "task"),
                        "jpeg":jpeg.base64EncodedString(),"fingerprint":fingerprint]
                    if let previous {body["previous"]=previous}
                    let reply=try await PhoneAgentTransport().decide(body,request:request)
                    try Task.checkCancellation()
                    guard self.generation==id,UUID(uuidString:reply.session)==id,
                          UUID(uuidString:reply.request_id)==request,reply.step==step,reply.fingerprint==fingerprint else {
                        throw PhoneControlFailure.message("画面或任务不匹配，已停止")
                    }
                    let d=reply.decision;try d.validate(observeOnly:observeOnly)
                    self.decisionMS=reply.decision_ms;self.status=d.message;self.intention=d.intent
                    if ["observe","done","ask"].contains(d.action) {return}
                    if d.action=="note" {
                        self.findings=Array((self.findings+[d.text]).suffix(12))
                        previous=self.receipt(request,"local_result","Discovery saved in Loki's private interests notebook.")
                        continue
                    }
                    if d.action=="wait" {
                        try await Task.sleep(for:.milliseconds(max(350,d.duration_ms)))
                        previous=self.receipt(request,"executed","Waited; inspect the next fresh screenshot.");continue
                    }
                    if d.action=="create_video" {
                        let result=try await PhoneVideoCreator.create(title:d.title,script:d.text)
                        previous=self.receipt(request,"local_result",result);self.completedSteps+=1;continue
                    }
                    let current=try await self.waitForFrame()
                    guard current.session==frame.session else {throw PhoneControlFailure.message("共享已改变，已停止")}
                    guard PhoneFrameConsistency.matches(frame.image,current.image,decision:d) else {
                        changedFrames+=1
                        guard changedFrames<=8 else {throw PhoneControlFailure.message("当前画面持续变化，操作已暂停")}
                        self.status="画面有变化，重新查看目标"
                        previous=self.receipt(request,"skipped_frame_changed","No input delivered: scene changed while deciding.")
                        continue
                    }
                    try await self.execute(d,frame:frame,id:id)
                    previous=self.receipt(request,"executed","Input acknowledged by ESP32. Inspect the actual screen result; delivery does not prove sending or publishing.")
                    changedFrames=0;self.completedSteps+=1
                    try await Task.sleep(for:.milliseconds(450))
                }
                self.status="本次探索已达到 160 步，已停止"
            } catch is CancellationError {
                if self.generation==id {self.status="操作已停止"}
            } catch {if self.generation==id {self.status=error.localizedDescription}}
            await PhoneAgentTransport().stop(id)
        }
    }
    private func receipt(_ id:UUID,_ state:String,_ detail:String)->[String:Any] {
        ["request_id":id.uuidString,"state":state,"detail":detail]
    }
    private func compressed(_ image:UIImage) throws -> Data {
        for width in [1024.0,768.0,576.0] {
            let scale=min(1,width/max(image.size.width,image.size.height))
            let format=UIGraphicsImageRendererFormat();format.scale=1
            let size=CGSize(width:image.size.width*scale,height:image.size.height*scale)
            let resized=UIGraphicsImageRenderer(size:size,format:format).image {_ in image.draw(in:CGRect(origin:.zero,size:size))}
            for quality in [0.6,0.4,0.25] {
                if let data=resized.jpegData(compressionQuality:quality),data.count<=90_000 {return data}
            }
        }
        throw PhoneControlFailure.message("当前画面无法压缩到可传输大小")
    }
    private func endTransitionTime() {
        if backgroundTask != .invalid {UIApplication.shared.endBackgroundTask(backgroundTask);backgroundTask = .invalid}
    }
    private func waitForFrame() async throws -> PhoneScreenFrame {
        let deadline=ContinuousClock.now.advanced(by:.seconds(8))
        while ContinuousClock.now<deadline {
            try Task.checkCancellation()
            if let frame=try? screen.current() {return frame}
            status="等待新画面…";try await Task.sleep(for:.milliseconds(150))
        }
        throw PhoneControlFailure.message("暂未收到新画面，请检查系统屏幕共享")
    }
    private func execute(_ d:PhoneVisualDecision,frame:PhoneScreenFrame,id:UUID) async throws {
        do {
            let connection=ble.generation
            _=try await ble.send(.arm,a:1)
            try Task.checkCancellation()
            let latest=try screen.current()
            guard generation==id,ble.generation==connection,latest.session==frame.session,
                  PhoneFrameConsistency.matches(frame.image,latest.image,decision:d) else {
                throw PhoneControlFailure.message("操作目标已变化，已停止")
            }
            let keyboard=PhoneKeyboard(ble)
            switch d.action {
            case "move":_=try await ble.send(.move,a:Int16(d.dx),b:Int16(d.dy))
            case "scroll":_=try await ble.send(.move,c:Int16(d.wheel))
            case "click","drag","long_press":
                _=try await ble.send(.button,a:1,b:1)
                if d.action=="drag" {try await keyboard.drag(dx:d.dx,dy:d.dy)}
                else {try await keyboard.hold(milliseconds:d.action=="long_press" ? d.duration_ms : 50)}
                _=try await ble.send(.button,a:1,b:0)
            case "home":try await keyboard.home()
            case "key":try await keyboard.key(d.key)
            case "type_text":try await keyboard.type(d.text)
            case "open_app":
                try await keyboard.home();try await keyboard.hold(milliseconds:450)
                try await keyboard.key("search");try await keyboard.hold(milliseconds:700)
                try await keyboard.type(d.text)
            default:throw PhoneControlFailure.message("未知操作，已停止")
            }
            _=try await ble.send(.release)
        } catch {ble.disconnect("操作已停止，请重新连接配件");throw error}
    }
}
