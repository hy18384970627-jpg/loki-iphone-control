#include <Arduino.h>
#include <BLEDevice.h>
#include <BLE2902.h>
#include <BLEHIDDevice.h>
#include <atomic>
#include <freertos/queue.h>
#include "control_protocol.h"
#include "hid_bridge.h"
#if defined(CONFIG_NIMBLE_ENABLED)
#include <host/ble_gatt.h>
#endif

HidBridge hid;
BLECharacteristic *reply=nullptr;
uint16_t control_service_handle=0;
uint16_t control_command_handle=0;
QueueHandle_t commands=nullptr;
std::atomic_bool overflow{false};
loki::Lease lease;
std::atomic_uint32_t sequence_snapshot{0};
bool previously_connected=false;
struct QueuedCommand { loki::Command value; uint32_t received_ms; };
#ifdef LOKI_WIRED_CONTROL
constexpr HidTarget target=HidTarget::usb;
bool target_connected() {return hid.usb_connected();}
#else
constexpr HidTarget target=HidTarget::ble;
bool target_connected() {return hid.ble_connected();}
#endif

class Writes final : public BLECharacteristicCallbacks {
    void onWrite(BLECharacteristic *characteristic) override {
        const auto bytes=characteristic->getValue();
        QueuedCommand command{}; command.received_ms=millis();
        if (!loki::decode(reinterpret_cast<const uint8_t *>(bytes.c_str()),bytes.length(),command.value) ||
            xQueueSend(commands,&command,0)!=pdTRUE) overflow.store(true);
    }
};
Writes writes;
class SessionRead final : public BLECharacteristicCallbacks {
    void onRead(BLECharacteristic *characteristic) override {
        // Reading state never arms, clears history, or generates HID input.
        uint8_t data[16]={'L','K',1,0};
        loki::put32(data+4,sequence_snapshot.load());
        data[12]=target_connected();
        characteristic->setValue(data,sizeof(data));
    }
};
SessionRead session_read;

void acknowledge(const loki::Command &command,loki::Status status,uint32_t duration) {
    uint8_t data[16]={'L','K',1,uint8_t(status)};
    loki::put32(data+4,command.seq);
    loki::put32(data+8,duration);
    data[12]=target_connected(); data[13]=lease.armed;
#ifdef LOKI_WIRED_CONTROL
    uint8_t response[20]{}; memcpy(response,data,16);loki::put32(response+16,loki::crc32(data,16));
    Serial.write(response,sizeof(response));
#else
    reply->setValue(data,sizeof(data)); reply->notify();
#endif
}
void setup() {
    Serial.begin(115200);
    commands=xQueueCreate(16,sizeof(QueuedCommand));
    if (!commands) { Serial.println("Loki queue allocation failed"); while(true) delay(1000); }
    hid.setup();
#ifndef LOKI_WIRED_CONTROL
    auto *service=hid.server()->createService(loki::kService);
    auto *command=service->createCharacteristic(loki::kCommand,
        BLECharacteristic::PROPERTY_WRITE|BLECharacteristic::PROPERTY_WRITE_ENC);
    command->setAccessPermissions(ESP_GATT_PERM_WRITE_ENCRYPTED);
    command->setCallbacks(&writes);
    reply=service->createCharacteristic(loki::kReply,
          BLECharacteristic::PROPERTY_READ|BLECharacteristic::PROPERTY_READ_ENC|BLECharacteristic::PROPERTY_NOTIFY);
    reply->setAccessPermissions(ESP_GATT_PERM_READ_ENCRYPTED);
    reply->setCallbacks(&session_read);
#if !defined(CONFIG_NIMBLE_ENABLED)
    reply->addDescriptor(new BLE2902());
#endif
    if (!service->start()) {
        Serial.println("LOKI_ERROR control_service_start_failed");
        while (true) delay(1000);
    }
    hid.start_ble_services();
    control_service_handle=service->getHandle();
#if defined(CONFIG_NIMBLE_ENABLED)
    // Query the live ATT database rather than relying on the wrapper's cached
    // service handle (characteristic value handles are filled by NimBLE).
    BLEUUID control_uuid(loki::kService);
    const int lookup=ble_gatts_find_svc(&control_uuid.getNative()->u,&control_service_handle);
    if (lookup!=0) control_service_handle=UINT16_MAX;
#endif
    control_command_handle=command->getHandle();
    if (control_service_handle==0 || control_service_handle==UINT16_MAX ||
        control_command_handle==0 || control_command_handle==UINT16_MAX ||
        reply->getHandle()==0 || reply->getHandle()==UINT16_MAX) {
        Serial.printf("LOKI_ERROR control_service_not_registered control=%u command=%u reply=%u\n",
            unsigned(control_service_handle),unsigned(control_command_handle),unsigned(reply->getHandle()));
        while (true) delay(1000);
    }
    // Fit HID + 128-bit control UUID in the 31-byte primary advertisement.
    // Keep the complete name in the scan response instead of dropping a UUID
    // to make room for the name and optional connection-interval fields.
    auto *advertising=BLEDevice::getAdvertising();
    BLEAdvertisementData advertised,scan_response;
    advertised.setFlags(0x06);
    advertised.setCompleteServices(BLEUUID(uint16_t(0x1812)));
    advertised.setCompleteServices(BLEUUID(loki::kService));
    advertised.setAppearance(GENERIC_HID);
    scan_response.setName("Loki S3 Control");
    if (!advertising->setAdvertisementData(advertised) || !advertising->setScanResponseData(scan_response)) {
        Serial.println("LOKI_ERROR advertising_configuration_failed");
        while (true) delay(1000);
    }
    if (!advertising->start()) {
        Serial.println("LOKI_ERROR advertising_start_failed");
        while (true) delay(1000);
    }
    Serial.printf("LOKI_GATT control=%u command=%u reply=%u\n",
        unsigned(control_service_handle),unsigned(command->getHandle()),unsigned(reply->getHandle()));
#endif
    Serial.printf("LOKI_READY protocol=1 flash=%lu psram=%lu armed=0 wifi=off\n",
                  (unsigned long)ESP.getFlashChipSize(),(unsigned long)ESP.getPsramSize());
}
void loop() {
    TickContext context{}; hid.tick(context);
    const bool connected=target_connected();
#ifndef LOKI_WIRED_CONTROL
    // More than one physical central makes HID ownership ambiguous. Fail closed.
    if (hid.server()->getConnectedCount()>1) {
        hid.release_all(); lease.armed=false; xQueueReset(commands); delay(1); return;
    }
#endif
#ifdef LOKI_WIRED_CONTROL
    static uint8_t incoming[20]{};static size_t length=0;static uint32_t last_byte_ms=0;
    if (length && uint32_t(millis()-last_byte_ms)>100) length=0;
    while(Serial.available()) {
        const uint8_t byte=Serial.read();
        last_byte_ms=millis();
        if (length==0 && byte!='L') continue;
        if (length==1 && byte!='K') {length=byte=='L'?1:0;continue;}
        incoming[length++]=byte;
        if (length==sizeof(incoming)) {
            QueuedCommand value{};value.received_ms=millis();
            if (loki::u32(incoming+16)!=loki::crc32(incoming,16) ||
                !loki::decode(incoming,16,value.value) || xQueueSend(commands,&value,0)!=pdTRUE) overflow.store(true);
            length=0;
        }
    }
#endif
    if (connected!=previously_connected) {
        hid.release_all(); lease={}; sequence_snapshot.store(0); xQueueReset(commands); previously_connected=connected;
    }
    if (overflow.exchange(false)) { hid.release_all(); lease.armed=false; xQueueReset(commands); }
    if (lease.expire(millis())) hid.release_all();
    QueuedCommand queued{};
    if (xQueueReceive(commands,&queued,0)==pdTRUE) {
        const auto &command=queued.value;
        if (uint32_t(millis()-queued.received_ms)>250) {
            hid.release_all(); lease.armed=false;
            acknowledge(command,loki::Status::stale,0); return;
        }
        const auto start=micros();
        auto status=lease.accept(command,millis());
        sequence_snapshot.store(lease.sequence);
        if (!connected && command.op!=loki::Op::ping && command.op!=loki::Op::release) {
            status=loki::Status::rejected;lease.armed=false;hid.release_all();
        }
        if (status==loki::Status::ok) {
            bool accepted=true;
            switch(command.op) {
                case loki::Op::move: hid.move_mouse(command.a,command.b,command.c,command.d,target); break;
                case loki::Op::button: accepted=hid.set_mouse_button(command.a,command.b!=0,target); break;
                case loki::Op::key: accepted=hid.key(command.a,command.b!=0,target); break;
                case loki::Op::consumer: accepted=hid.consumer(command.a,command.b!=0,target); break;
                case loki::Op::release: hid.release_all(); break;
                case loki::Op::arm: if (!lease.armed) hid.release_all(); break;
                default: break;
            }
            if (!accepted) { status=loki::Status::rejected; hid.release_all(); lease.armed=false; }
        }
        acknowledge(command,status,micros()-start);
    }
#ifndef LOKI_WIRED_CONTROL
    // BLE variant: USB serial remains a read-only diagnostic channel.
    while(Serial.available()) if (Serial.read()=='?') {
        Serial.printf("LOKI_STATUS ble=%d armed=%d seq=%lu control=%u command=%u reply=%u\n",connected,lease.armed,
            (unsigned long)lease.sequence,unsigned(control_service_handle),unsigned(control_command_handle),
            unsigned(reply->getHandle()));
        hid.print_ble_diagnostics();
    }
#endif
    delay(1);
}
