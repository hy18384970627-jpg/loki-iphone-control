import base64
import hashlib
import io
import sys
import threading
import unittest
import uuid
from pathlib import Path
from PIL import Image

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from phone_autonomy import PhoneAutonomy, LANGUAGE_POLICY, validate

class Problem(Exception):
    def __init__(self,status,code):self.status=status;self.code=code

def decision(action='type_text',text='How delightfully predictable.'):
    return dict(action=action,dx=0,dy=0,wheel=0,cursor_visible=True,
        cursor_x=.5,cursor_y=.5,target_left=.4,target_top=.4,target_right=.6,target_bottom=.6,
        needs_confirmation=False,message='Composing a reply.',text=text,key='',duration_ms=0,
        source_url='',title='',intent='Reply as Loki in English.',observation='A focused reply field is visible.')

def frame():
    buf=io.BytesIO();Image.new('RGB',(128,256),'white').save(buf,format='JPEG');jpeg=buf.getvalue()
    return dict(session=str(uuid.uuid4()),request_id=str(uuid.uuid4()),step=0,mode='roam',
        goal='',jpeg=base64.b64encode(jpeg).decode(),fingerprint=hashlib.sha256(jpeg).hexdigest())

class AutonomyTests(unittest.TestCase):
    def make(self,model,journal=lambda *args:None):
        control=PhoneAutonomy(Problem,model,lambda:{'existing_identity':'Loki understands Chinese.'},journal)
        self.addCleanup(control.pool.shutdown,wait=True)
        return control

    def test_english_search_post_reply_and_video_guards(self):
        for action,text,title in [('type_text','你好',''),('type_text','Hello 朋友',''),
            ('open_app','微信',''),('create_video','English script. '*8,'中文标题'),
            ('create_video','中文旁白'*30,'A discovery'),('note','I found 中文.','Discovery')]:
            with self.subTest(action=action,text=text),self.assertRaises(ValueError):
                validate({**decision(action,text),'title':title})
        for action,text in [('open_app','WeChat'),('type_text','Loki mythology'),
            ('type_text','You have my attention. Do make it worthwhile.'),
            ('create_video','A curious discovery, and one I intend to investigate. '*3)]:
            self.assertEqual(action,validate(decision(action,text))['action'])

    def test_chinese_task_is_understood_but_output_policy_is_english(self):
        seen=[];ready=threading.Event()
        async def model(context,jpeg):seen.append(context);ready.set();return decision(),{}
        control=self.make(model);body={**frame(),'mode':'task','goal':'打开社交媒体回复这条中文评论'}
        control.submit(body);self.assertTrue(ready.wait(2));control.pool.shutdown(wait=True)
        self.assertEqual(body['goal'],seen[0]['goal'])
        self.assertEqual(LANGUAGE_POLICY,seen[0]['language_policy'])
        self.assertEqual('en',seen[0]['language_policy']['external_output_language'])
        self.assertEqual('complete',control.result(body['request_id'])['state'])

    def test_uncertain_submit_can_be_polled_without_duplicate_generation(self):
        entered=threading.Event();resume=threading.Event();calls=[]
        async def model(context,jpeg):calls.append(1);entered.set();resume.wait(2);return decision(),{}
        control=self.make(model);body=frame();control.submit(body)
        self.assertTrue(entered.wait(2));self.assertEqual('pending',control.submit(body)['state'])
        self.assertEqual('pending',control.result(body['request_id'])['state'])
        resume.set();control.pool.shutdown(wait=True)
        self.assertEqual([1],calls)
        self.assertEqual('complete',control.result(body['request_id'])['state'])
        with self.assertRaises(Problem):control.submit({**body,'goal':'changed'})

    def test_chinese_model_content_never_becomes_an_executable_reply(self):
        async def model(context,jpeg):return decision(text='你好，我是Loki'),{}
        control=self.make(model);body=frame();control.submit(body);control.pool.shutdown(wait=True)
        self.assertEqual('failed',control.result(body['request_id'])['state'])
        self.assertIsNone(control.result(body['request_id'])['reply'])

    def test_stop_during_model_call_prevents_action_and_note_write(self):
        entered=threading.Event();resume=threading.Event();notes=[]
        async def model(context,jpeg):entered.set();resume.wait(2);return decision('note','An intriguing discovery.'),{}
        control=self.make(model,lambda *args:notes.append(args));body=frame();control.submit(body)
        self.assertTrue(entered.wait(2));control.stop(body);resume.set();control.pool.shutdown(wait=True)
        self.assertEqual([],notes);self.assertEqual('failed',control.result(body['request_id'])['state'])

    def test_next_decision_needs_execution_receipt_and_retains_english_content(self):
        seen=[]
        async def model(context,jpeg):seen.append(context);return decision(),{}
        control=self.make(model);body=frame();control.submit(body);control.pool.shutdown(wait=True)
        next_body={**body,'step':1,'request_id':str(uuid.uuid4())}
        with self.assertRaises(Problem):control.submit(next_body)
        # A fresh executor is unnecessary for validating the rejected receipt.
        self.assertEqual(1,len(seen))

if __name__=='__main__':unittest.main()
