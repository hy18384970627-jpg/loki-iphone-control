import base64
import hashlib
import io
import sys
import threading
import unittest
import uuid
from pathlib import Path
from PIL import Image
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from phone_screen_control import PhoneScreenControl, validate_decision

class Problem(Exception):
    def __init__(self,status,code):self.status=status;self.code=code

def decision(action='move'):
    return dict(action=action,dx=10 if action=='move' else 0,dy=0,wheel=0,cursor_visible=True,
        cursor_x=.5,cursor_y=.5,target_left=.4,target_top=.4,target_right=.6,target_bottom=.6,
        needs_confirmation=False,message='查看目标')

def frame():
    data=io.BytesIO();Image.new('RGB',(128,256),'white').save(data,format='JPEG');jpeg=data.getvalue()
    return dict(session=str(uuid.uuid4()),request_id=str(uuid.uuid4()),step=0,goal='打开设置',observe_only=False,
                jpeg=base64.b64encode(jpeg).decode(),fingerprint=hashlib.sha256(jpeg).hexdigest())

class ScreenTests(unittest.TestCase):
    def test_no_unseen_cursor_or_combined_or_unconfirmed_action(self):
        for patch in ({'cursor_visible':False},{'dx':41},{'dx':True},{'needs_confirmation':True},
                      {'action':'click','dx':1},{'action':'click','dx':0,'cursor_x':.9},
                      {'cursor_x':float('nan')},{'action':'shell'}):
            with self.subTest(patch=patch),self.assertRaises(ValueError):validate_decision({**decision(),**patch})
        self.assertEqual('click',validate_decision(decision('click'))['action'])
        with self.assertRaises(ValueError):validate_decision(decision(),True)

    def test_replay_and_goal_change_cannot_generate_more_actions(self):
        calls=[]
        async def model(context,jpeg):calls.append(context);return decision(),{}
        control=PhoneScreenControl(Problem,model);body=frame()
        result=control.step(body)
        self.assertEqual(body['fingerprint'],result['fingerprint'])
        self.assertEqual(body['request_id'],result['request_id'])
        for request in (body,{**body,'step':1,'goal':'changed'}):
            with self.assertRaises(Problem):control.step(request)
        self.assertEqual(1,len(calls))

    def test_stop_during_inference_cannot_return_an_action(self):
        entered=threading.Event();resume=threading.Event();errors=[]
        async def model(context,jpeg):entered.set();resume.wait(3);return decision(),{}
        control=PhoneScreenControl(Problem,model);body=frame()
        def run():
            try:control.step(body)
            except Problem as error:errors.append(error.code)
        thread=threading.Thread(target=run);thread.start();self.assertTrue(entered.wait(2))
        control.stop(body);resume.set();thread.join(3)
        self.assertEqual(['screen_session_stopped'],errors)

    def test_mismatched_pixels_and_non_images_never_reach_model(self):
        calls=[]
        async def model(context,jpeg):calls.append(1);return decision(),{}
        control=PhoneScreenControl(Problem,model);body=frame()
        for patch in ({'fingerprint':'0'*64},{'jpeg':'http://example.org/private.jpg'},
                      {'step':16},{'observe_only':'false'}):
            with self.subTest(patch=patch),self.assertRaises(Problem):control.step({**body,**patch})
        self.assertEqual([],calls)

    def test_uncertain_model_request_is_not_replayed(self):
        calls=[]
        async def model(context,jpeg):calls.append(1);raise TimeoutError()
        control=PhoneScreenControl(Problem,model);body=frame()
        for _ in range(2):
            with self.assertRaises(Problem):control.step(body)
        self.assertEqual([1],calls)

if __name__=='__main__':unittest.main()
